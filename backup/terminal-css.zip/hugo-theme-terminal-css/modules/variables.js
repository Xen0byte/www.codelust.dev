export const defaultValues = {
  background: "#1a170f",
  foreground: "#eceae5",
  accent: "#eec35e",
  fontSize: "1rem",
  lineHeight: "1.54em",
  radius: "0",
};
